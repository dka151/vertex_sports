// Scroll progress bar (injected so no HTML edits per page)
const progress = document.createElement('div');
progress.className = 'scroll-progress';
document.body.appendChild(progress);

// Sticky header shadow + scroll progress
const header = document.getElementById('header');
const onScroll = () => {
  if (header) header.classList.toggle('scrolled', window.scrollY > 10);
  const h = document.documentElement;
  const max = h.scrollHeight - h.clientHeight;
  const pct = max > 0 ? (h.scrollTop / max) * 100 : 0;
  progress.style.width = pct + '%';
};
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

// Mobile menu toggle
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => {
    const open = mobileMenu.classList.toggle('open');
    hamburger.setAttribute('aria-expanded', String(open));
  });
  mobileMenu.querySelectorAll('a').forEach(a =>
    a.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
    })
  );
}

// Contact form: validate, then send via Web3Forms if a key is set,
// otherwise fall back to the visitor's email client (mailto).
const form = document.getElementById('contactForm');
const status = document.getElementById('formStatus');
const CONTACT_TO = 'info@vistechpro.com';

if (form && status) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const company = form.company ? form.company.value.trim() : '';
    const message = form.message.value.trim();
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

    if (!name || !emailOk || !message) {
      status.textContent = 'Please fill in your name, a valid email, and a message.';
      status.className = 'form__status form__status--error';
      return;
    }

    const keyField = form.querySelector('input[name="access_key"]');
    const key = keyField ? keyField.value.trim() : '';
    const keyConfigured = key && key !== 'YOUR_WEB3FORMS_ACCESS_KEY';

    // --- Path A: live delivery via Web3Forms (AJAX, no page reload) ---
    if (keyConfigured) {
      const btn = form.querySelector('button[type="submit"]');
      const original = btn ? btn.textContent : '';
      if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
      status.textContent = '';
      status.className = 'form__status';
      try {
        const res = await fetch(form.action, { method: 'POST', body: new FormData(form) });
        const data = await res.json();
        if (data.success) {
          status.textContent = `Thanks ${name}, your message has been sent. We'll be in touch at ${email}.`;
          status.className = 'form__status form__status--ok';
          form.reset();
        } else {
          throw new Error(data.message || 'Submission failed');
        }
      } catch (err) {
        status.textContent = 'Sorry, something went wrong sending your message. Please email info@vistechpro.com directly.';
        status.className = 'form__status form__status--error';
      } finally {
        if (btn) { btn.disabled = false; btn.textContent = original; }
      }
      return;
    }

    // --- Path B: fallback — open the visitor's email client ---
    const subject = encodeURIComponent(`Enquiry from ${name}${company ? ' (' + company + ')' : ''}`);
    const body = encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\nCompany: ${company || '—'}\n\n${message}`
    );
    window.location.href = `mailto:${CONTACT_TO}?subject=${subject}&body=${body}`;
    status.textContent = `Thanks ${name} — your email app should open to send this to ${CONTACT_TO}. If it doesn't, email us there directly.`;
    status.className = 'form__status form__status--ok';
  });
}

// Reveal-on-scroll for cards and modern sections
const revealEls = document.querySelectorAll('.card, .feature, .chip, .valueprop, .tstep, .value, .service-row, .client-chip, .founder, .fact');
revealEls.forEach(el => { el.style.opacity = '0'; el.style.transform = 'translateY(16px)'; el.style.transition = 'opacity .5s ease, transform .5s ease'; });
const revealObserver = new IntersectionObserver((entries, obs) => {
  entries.forEach((e, i) => {
    if (e.isIntersecting) {
      e.target.style.transitionDelay = `${(i % 3) * 60}ms`;
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
      obs.unobserve(e.target);
    }
  });
}, { threshold: 0.15 });
revealEls.forEach(el => revealObserver.observe(el));
